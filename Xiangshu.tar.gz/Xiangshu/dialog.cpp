#include "dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent), ui(new Ui::Dialog)
{
        ui->setupUi(this);


}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{

}

void Dialog::on_comboBox_activated(const QString &arg1)
{
    int i;
    int yearr;
    ui->listyear->clear();
    yearr=arg1.mid(0,4).toInt();
    for(i=0;i<10;i++){
        ui->listyear->addItem(QString::number(yearr+i));
    }
}

void Dialog::on_listyear_itemClicked(QListWidgetItem *item)
{
    // QStringList list ="123";
    ui->tableView->horizontalHeaderItem(0)->setText(item->text());
}



void Dialog::on_tableXS_itemChanged(QTableWidgetItem *item)
{
    ui->tableView->setItem(0,item->column(),new QTableWidgetItem(item->text()));
   // ui->listyear->addItem(item->text());
}
