#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include "ui_XiangShu.h"

class Dialog : public QDialog
{
    Q_OBJECT
public:
    Dialog(QWidget *parent = 0);

    ~Dialog();
private slots:
    void on_pushButton_clicked();

    void on_comboBox_activated(const QString &arg1);

    void on_listyear_itemClicked(QListWidgetItem *item);

    void on_tableXS_cellDoubleClicked(int row, int column);

    void on_tableXS_cellChanged(int row, int column);

    void on_tableXS_itemChanged(QTableWidgetItem *item);

private:
     Ui::Dialog *ui;
};

#endif // DIALOG_H
